/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DatabaseProcess;

/**
 *
 * @author Thanh Phat
 */
public class ShareData {
    public static User useraccount;
    public static NhanVienQuanLy nvql;
    public static NhanVien nv;
    public static String maKhachHang;
    public static KhachHang thongTinKhachHang;
    public static String maHoaDon;
    public static HoaDon thongTinHoaDon;
    public static String maPhong;
    public static int tongTien;
    public static String ngayDatPhong;
    public static String ngayTraPhong;
    public static String maDatPhong;
    public static int maTk;
}

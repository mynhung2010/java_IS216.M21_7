/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DatabaseProcess;

import ConnectDB.ConnectionUtils;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Thanh Phat
 */
public class HoaDon {
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    
    private String maHoaDon, maKhachHang, maDichVu,maPhong;
    private int tongTien;
    private String phuongThuc;
    private String ngayTraTien;

    /**
     * Các hàm constructor + get/set
     */
    public HoaDon() {
    }

    public HoaDon(String maHoaDon, String maKhachHang, String maDichVu, String maPhong, int tongTien, String phuongThuc, String ngayTraTien) {
        this.maHoaDon = maHoaDon;
        this.maKhachHang = maKhachHang;
        this.maDichVu = maDichVu;
        this.maPhong = maPhong;
        this.tongTien = tongTien;
        this.phuongThuc = phuongThuc;
        this.ngayTraTien = ngayTraTien;
    }

    public String getPhuongThuc() {
        return phuongThuc;
    }

    public void setPhuongThuc(String phuongThuc) {
        this.phuongThuc = phuongThuc;
    }

    public String getNgayTraTien() {
        return ngayTraTien;
    }

    public void setNgayTraTien(String ngayTraTien) {
        this.ngayTraTien = ngayTraTien;
    }



    public String getMaHoaDon() {
        return maHoaDon;
    }

    public void setMaHoaDon(String maHoaDon) {
        this.maHoaDon = maHoaDon;
    }

    public String getMaKhachHang() {
        return maKhachHang;
    }

    public void setMaKhachHang(String maKhachHang) {
        this.maKhachHang = maKhachHang;
    }

    public String getMaDichVu() {
        return maDichVu;
    }

    public void setMaDichVu(String maDichVu) {
        this.maDichVu = maDichVu;
    }

    public String getMaPhong() {
        return maPhong;
    }

    public void setMaPhong(String maPhong) {
        this.maPhong = maPhong;
    }

    public int getTongTien() {
        return tongTien;
    }

    public void setTongTien(int tongTien) {
        this.tongTien = tongTien;
    }
    
    
    /**
     * Lấy thông tin các hóa đơn
     * @return
     * @throws SQLException
     * @throws ClassNotFoundException 
     */
    public List<HoaDon> getFullData() throws SQLException, ClassNotFoundException {
        Connection conn = ConnectionUtils.getMyConnection();
        String query = " select p.BillNo, b.CusNo, RoomNo, SumOfMoney, Method, PaymentDate "
                     + " from bill b join pay p on b.BillNo = p.BillNo "
                     + " order by b.BillNo";
        Statement stat = conn.createStatement();
        try(ResultSet kq = stat.executeQuery(query)){
            List<HoaDon> hoaDonData = new ArrayList<>();
            
            while(kq.next()){
                HoaDon hd = new HoaDon();
                
                hd.setMaHoaDon(kq.getString("BillNo"));
                
                hd.setMaKhachHang(kq.getString("CusNo"));
                
                hd.setMaPhong(kq.getString("RoomNo"));
                
                hd.setTongTien(kq.getInt("sumOfMoney"));
                
                int phuongThuc = 0;
                phuongThuc = kq.getInt("Method");
                
                if(phuongThuc == 1)
                    hd.setPhuongThuc("COD");
                else
                    hd.setPhuongThuc("Chuyển khoản");
                
                String payDate = "";
                payDate = sdf.format(kq.getDate("PaymentDate"));
                hd.setNgayTraTien(payDate);
                
                hoaDonData.add(hd);
            }
            return hoaDonData;
        }
    }
    
    
    /**
     * Tìm kiếm thông tin các hóa đơn
     * @param Bill_No
     * @return
     * @throws SQLException
     * @throws ClassNotFoundException 
     */
    public List<HoaDon> timKiemHoaDon(String Bill_No) throws SQLException, ClassNotFoundException {
        Connection conn = ConnectionUtils.getMyConnection();
        String query = " select p.BillNo, b.CusNo, RoomNo, SumOfMoney, Method, PaymentDate "
                     + " from bill b join pay p on b.BillNo = p.BillNo "
                     + " where b.BillNo = '" + Bill_No + "'";
        Statement stat = conn.createStatement();
        try(ResultSet kq = stat.executeQuery(query)){
            List<HoaDon> hoaDonData = new ArrayList<>();
            
            while(kq.next()){
                HoaDon hd = new HoaDon();
                
                
                hd.setMaHoaDon(kq.getString("BillNo"));
                
                hd.setMaKhachHang(kq.getString("CusNo"));
                
                hd.setMaPhong(kq.getString("RoomNo"));
                
                hd.setTongTien(kq.getInt("sumOfMoney"));
                
                int phuongThuc = 0;
                phuongThuc = kq.getInt("Method");
                
                if(phuongThuc == 1)
                    hd.setPhuongThuc("COD");
                else
                    hd.setPhuongThuc("Chuyen khoan");
                
                String payDate = "";
                payDate = sdf.format(kq.getDate("PaymentDate"));
                hd.setNgayTraTien(payDate);
                
                hoaDonData.add(hd);
            }
            return hoaDonData;
        }
    }
}
